/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vowels;

import java.util.Scanner;

/**
 *
 * @author Abhilash
 */
public class abhilash {
    Scanner sc= new Scanner(System.in);
    String s = sc.nextLine();
    int j=0;
    for(int i=0;i<s.length();)
    {
        String subString="";
        while(true && j<s.length()-1)
        {
            char a= s.charAt(j);
            char b= s.charAt(j+1);
            if((int)a<(int)b){
                if(subString.length() == 0) {
            subString=subString.concat(Character.toString(a)).concat(Character.toString(b));
            }
            else{
            subString=subString.concat(Character.toString(b));
            }
                j++;
            }
            else{
                   i=j+2;
                   j++;
                   break;
            }
         
            }
        recursion(subString);
        }
    }

private static void recursion(String subString){
while(subString.length()>=2)
{
recursion2(subString);
subString=subString.substring(substring.length()-(subString.length()-1));

}
}
private static void recursion2(String subString){
while(subString.length()>=2){
System.out.println(subString)
subString=subString.substring(0,subStrng.length()-1);
}
}
